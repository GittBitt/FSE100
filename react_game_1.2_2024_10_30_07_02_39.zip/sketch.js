let circles = [];
let currentNumber = 1;

function setup() {
  createCanvas(500, 500);
  for (let i = 0; i < 5; i++) {
    let x = random(50, 350);
    let y = random(50, 350);
    circles.push(new Circle(x, y, i + 1));
  }
}

function draw() {
  background(220);
  for (let circle of circles) {
    circle.show();
  }
  fill(0);
  textSize(34);
  textAlign(CENTER);
  text("Next Number: " + currentNumber, width / 2, height - 30);
}

function mousePressed() {
  for (let i = circles.length - 1; i >= 0; i--) {
    if (circles[i].contains(mouseX, mouseY)) {
      if (circles[i].number === currentNumber) {
        circles.splice(i, 1);
        currentNumber++;
      }
      break;
    }
  }
}

class Circle {
  constructor(x, y, number) {
    this.x = x;
    this.y = y;
    this.number = number;
    this.r = 20;
  }

  contains(px, py) {
    let d = dist(px, py, this.x, this.y);
    return d < this.r;
  }

  show() {
    fill(255);
    stroke(0);
    strokeWeight(2);
    ellipse(this.x, this.y, this.r * 2);
    fill(0);
    noStroke();
    textSize(16);
    textAlign(CENTER, CENTER);
    text(this.number, this.x, this.y);
  }
}
